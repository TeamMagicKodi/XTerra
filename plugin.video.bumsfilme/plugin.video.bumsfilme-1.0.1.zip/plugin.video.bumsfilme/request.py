#!/usr/bin/python
# -*- coding: utf-8 -*-
import urllib2
def requesthandler(url,security_headers=None):
    try:
        opener = urllib2.build_opener()
        opener.addheaders = [('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:40.0) Gecko/20100101 Firefox/40.1'),('Accept-Language', 'de-de,de;q=0.8,en-us;q=0.5,en;q=0.3'),('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8')]
        if not security_headers == None:
            opener.addheaders = security_headers
        response = opener.open(url,timeout=30)
        urlData = response.read()
        response.close()
        return urlData
    except:
        return ''