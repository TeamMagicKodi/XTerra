# -*- coding: utf-8 -*-
#------------------------------------------------------------
# KidsTube
# (c) 2017 - SGK/KodiUnlimitedSupport
# Based on code from youtube addon
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.KidsTube'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')
ART = xbmc.translatePath(os.path.join('special://home/addons/' + addonID + '/resources/art/'))

channellist=[
    ("[COLORyellow]>> [COLORred][B]YOUTUBE[/B][/COLOR] Kanäle[/COLOR]", "Kanäle", "http://sgkodi.de/KidsTube/Daten/YT.png"),
    ("[COLORyellow]>> Serien[/COLOR]", "Serien", "http://sgkodi.de/KidsTube/Daten/Serien.png"),
	("[COLORyellow]>> Filme[/COLOR]", "Filme", "http://sgkodi.de/KidsTube/Daten/Filme.png"),
    ("[COLORyellow]>> Märchen[/COLOR]", "Geschichten", "http://sgkodi.de/KidsTube/Daten/Saga.png"),
	("[COLORyellow]>> Hörbücher[/COLOR]", "Buch", "http://sgkodi.de/KidsTube/Daten/Books.png"),
    ("[COLORyellow]>> Wissen[/COLOR]", "Wissen", "http://sgkodi.de/KidsTube/Daten/Wissen.png"),
	("[COLORyellow]>> Musik[/COLOR]", "Musik", "http://sgkodi.de/KidsTube/Daten/Musik.png"),
	]

sublists = {
'Kanäle':[
     ("[COLORyellow]KIKA[/COLOR] von ARD & ZDF", "user/meinKiKA", "http://sgkodi.de/KidsTube/Daten/KiKa.png"),
	 ("[COLORyellow]KiKANiNCHEN[/COLOR] von ARD & ZDF", "playlist/PLizIMM-aNCovzkx9ExqoYxmIzy8mf2pgk", "http://sgkodi.de/KidsTube/Daten/KiKaJR.png"),
     ("[COLORyellow]ZDFtivi[/COLOR] von ZDF", "user/ZDFtiviKinder", "http://sgkodi.de/KidsTube/Daten/Tivi.png"),
     ("[COLORyellow]Löwenzahn TV[/COLOR] von ZDF", "channel/UCOPJAVJeBhqWL8k7K9Wx6SQ", "http://sgkodi.de/KidsTube/Daten/Zahn.png"),
	 ("[COLORyellow]Sesamstrasse[/COLOR] von NDR", "user/SesamstrasseNDR", "http://sgkodi.de/KidsTube/Daten/Sesam.png"),
	 ("[COLORyellow]Kindernetz[/COLOR] von SWR", "user/Kindernetz", "http://sgkodi.de/KidsTube/Daten/Kinder.png"),
	 ("[COLORyellow]Die Sendung mit der Maus[/COLOR] von WDR", "channel/UCk4sjM2_HAKyCztmtlg31_A", "http://sgkodi.de/KidsTube/Daten/Maus.png"),
	 ("[COLORyellow]Toggolino[/COLOR] von SuperRTL", "user/TOGGOLINOde", "http://sgkodi.de/KidsTube/Daten/Toggo.png"),
	 ("[COLORyellow]Disney Channel[/COLOR] Deutschland", "user/DisneyChannelGermany", "http://sgkodi.de/KidsTube/Daten/Disney.png"),
	 ("[COLORyellow]Disney Junior[/COLOR] Deutschland", "user/DisneyJuniorGermany", "http://sgkodi.de/KidsTube/Daten/DisneyJR.png"),
	 ("[COLORyellow]Nickelodeon[/COLOR] Deutschland", "user/nickelodeonoffiziell", "http://sgkodi.de/KidsTube/Daten/Nick.png"),
	 ("[COLORyellow]Boomerang[/COLOR] Deutschland", "user/BoomerangDE", "http://sgkodi.de/KidsTube/Daten/Boom.png"),
	 ("[COLORyellow]Cartoon Network[/COLOR] Deutschland", "user/cartoonnetworkde", "http://sgkodi.de/KidsTube/Daten/Cartoon.png"),
	 ("[COLORyellow]Kixi[/COLOR] Kinderfilme, Lehrfilme, Lernserien", "channel/UCF2IFFQyO5gbhvOCObh1WTQ", "http://sgkodi.de/KidsTube/Daten/Kixi.png"),
	 ("[COLORyellow]Ric TV[/COLOR]", "user/RICTVChannel", "http://sgkodi.de/KidsTube/Daten/Ric.png"),
	 ],

'Serien':[
     ("[COLORyellow]Feuerwehrman Sam[/COLOR]", "playlist/PLk_wkm2F99xf0qpmqfxKmq4wA57Bc5h2m", "http://sgkodi.de/KidsTube/Daten/Sam.png"),
     ("[COLORyellow]Bob der Baumeister[/COLOR]", "playlist/PLncbaDTLgEzTBs4HQ-uJA_6zcTiOLeIva", "http://sgkodi.de/KidsTube/Daten/Bob.png"),
     ("[COLORyellow]Peppa Pig[/COLOR]", "playlist/PL-FT6FZj-9bmWTGmd77VIixZ5aRW7d6V9", "http://sgkodi.de/KidsTube/Daten/Peppa.png"),
	 ("[COLORyellow]Die Fixies[/COLOR]", "playlist/PLMu5a51zMv6zUI7ydYUdLkwHLyAq9mlw5", "http://sgkodi.de/KidsTube/Daten/Fixies.png"),
     ("[COLORyellow]Caillou[/COLOR]", "playlist/PLYbELRCXraUV5CxUx0VFqALe5B2NOnDM-", "http://sgkodi.de/KidsTube/Daten/Caillou.png"),
     ("[COLORyellow]Tom der Abschleppwagen[/COLOR]", "playlist/PLfrJ8rAzdNSWKpsTGcZGNLyjsVDiwyj90", "http://sgkodi.de/KidsTube/Daten/Tom.png"),
     ("[COLORyellow]Bali[/COLOR]", "playlist/PLDwoYRM80FiQ3V4BM5HUTs2hvrB5H4RAt", "http://sgkodi.de/KidsTube/Daten/Bali.png"),
	 ("[COLORyellow]Der kleine Nick[/COLOR]", "playlist/PLUeQT57BFaE5bMuMxs2zhCJHgweiJMxxY", "http://sgkodi.de/KidsTube/Daten/KleinNick.png"),
	 ("[COLORyellow]Peter Pan[/COLOR] Spannende Abenteuer", "playlist/PLEsSrAkc-N6rXexCXeRYvk3m69rYU6LmT", "http://sgkodi.de/KidsTube/Daten/Peter.png"),
	 ("[COLORyellow]Wendy[/COLOR] Pferde sind ihr Leben", "playlist/PLAqP3cngI26r65PV1PZbYoSc5sjMHmt2_", "http://sgkodi.de/KidsTube/Daten/Wendy.png"),
	 ("[COLORyellow]Justice League[/COLOR] DC Kids", "playlist/PLWH6DXF9upwP53YyfSKaLD_XbMwwgphuB", "http://sgkodi.de/KidsTube/Daten/Justice.png"),
	 ("[COLORyellow]Benjamin Blümchen[/COLOR] BenjaminBlümchen.tv", "playlist/PL1SAyTUFBb74hUX32r6aqasGENGL4YShb", "http://sgkodi.de/KidsTube/Daten/Ben.png"),
	 ("[COLORyellow]Bibi Blocksberg[/COLOR] BibiBlocksberg.tv", "playlist/PLOZg6nrLYB7-EgluZK6CuMBzJtKhvFIAU", "http://sgkodi.de/KidsTube/Daten/Bibi.png"),
	 ("[COLORyellow]Mister Bean[/COLOR]", "playlist/PLiDbV9ObbZLV_R9ofcSdJSPP4PSrobk3g", "http://sgkodi.de/KidsTube/Daten/Bean.png"),
	 ("[COLORorange]Pink Panther[/COLOR] 1. Klassik Serie", "playlist/PL546904B9DC923B31", "http://sgkodi.de/KidsTube/Daten/Pink1.png"),
	 ("[COLORlime]Pink Panther[/COLOR] 2. Die neue Serie", "playlist/PL2MVdpCy9PxFMwC6UaXwNOTZMPUxiU6KB", "http://sgkodi.de/KidsTube/Daten/Pink2.png"),
	 ("[COLORorange]Tom & Jerry[/COLOR] 1. Klassik Serie", "playlist/PLwp8m9anCLK3jmItMyLTgfNpM-526z8Cl", "http://sgkodi.de/KidsTube/Daten/Jerry1.png"),
	 ("[COLORlime]Tom & Jerry[/COLOR] 2. Die neue Serie", "playlist/PL2MVdpCy9PxFf_BZJfjTtNuXTBdyu1ig9", "http://sgkodi.de/KidsTube/Daten/Jerry2.png"),
     ("[COLORorange]Wickie und die starken Männer[/COLOR] 1. Klassik Serie", "playlist/PLGP11O3gIZb-CAn5df2AE687pqGLxv2hr", "http://sgkodi.de/KidsTube/Daten/Wickie1.png"),
	 ("[COLORlime]Wickie und die starken Männer[/COLOR] 2. Die neue Serie", "playlist/PLGP11O3gIZb8jsxU_InVjehKgJy1Z1Eyj", "http://sgkodi.de/KidsTube/Daten/Wickie2.png"),
	 ("[COLORorange]Biene Maja[/COLOR] 1. Klassik Serie", "playlist/PLdHRcaRTf6chVA47IIGwDRJbvgkgBS6Xz", "http://sgkodi.de/KidsTube/Daten/Maja1.png"),
	 ("[COLORlime]Biene Maja[/COLOR] 2. Die neue Serie", "playlist/PLdHRcaRTf6cie56jn0JUsHVGMMSU4AqY-", "http://sgkodi.de/KidsTube/Daten/Maja2.png"),
	 ("[COLORorange]Heidi[/COLOR] 1. Klassik Serie", "playlist/PLwz9HrBqSQF_iY4v1WuKJeE6CnsPo3K2a", "http://sgkodi.de/KidsTube/Daten/Heidi1.png"),
	 ("[COLORlime]Heidi[/COLOR] 2. Die neue Serie", "playlist/PLwz9HrBqSQF9Y9W6hf-AwwBxTunNYrFvA", "http://sgkodi.de/KidsTube/Daten/Heidi2.png"),
	 ("[COLORorange]Das Dschungelbuch[/COLOR] 1. Klassik Serie", "playlist/PLYekapbFEdMmzDN29jkQwATMx3BgznsdM", "http://sgkodi.de/KidsTube/Daten/Mogli1.png"),
	 ("[COLORlime]Das Dschungelbuch[/COLOR] 2. Die neue Serie", "playlist/PLpoo_9xCCIPi2n-J0b6OC7138RjR7dgRx", "http://sgkodi.de/KidsTube/Daten/Mogli2.png"),
	 ("[COLORorange]Robin Hood[/COLOR] 1. Klassik Serie", "playlist/PLYekapbFEdMlSWa8pmtr1EEQGI3lEofb3", "http://sgkodi.de/KidsTube/Daten/Robin1.png"),
	 ("[COLORlime]Robin Hood[/COLOR] 2. Die neue Serie", "playlist/PLh1m-wgEIaUifSq9gyRdpIT_k7_fCN0UE", "http://sgkodi.de/KidsTube/Daten/Robin2.png"),
	 ("[COLORorange]Die Schlümpfe[/COLOR] 1. Klassik Serie", "playlist/PLe9POcs8knUCprw4_XXxTm8hkGBVw6NHs", "http://sgkodi.de/KidsTube/Daten/Schlumpf1.png"),
	 ("[COLORorange]Simba der Löwenkönig[/COLOR] 1. Klassik Serie", "playlist/PLYekapbFEdMlAfVPEpc9EQxHP4nCIXd3T", "http://sgkodi.de/KidsTube/Daten/Simba.png"),
	 ("[COLORorange]Christoph Columbus[/COLOR] 1. Klassik Serie", "playlist/PLYekapbFEdMnpBAXde80pONK86-k_TPFl", "http://sgkodi.de/KidsTube/Daten/Chris.png"),	 
	 ("[COLORorange]Meister Eder & sein Pumuckl[/COLOR] 1. Klassik Serie", "playlist/PLRjCg79wQp3Iit2xI5LTWbLvH92hgu7xE", "http://sgkodi.de/KidsTube/Daten/Pumuckl.png"),
	 ("[COLORorange]Calimero[/COLOR] 1. Klassik Serie", "channel/UCnjYE_WVG0PMRH6HSlWJr5Q", "http://sgkodi.de/KidsTube/Daten/Calimero1.png"),
	 ("[COLORorange]Grisu der kleine Drache[/COLOR] 1. Klassik Serie", "playlist/PLOE3ysCGNx-1kamFgtU8gGwIvuPmI2FEi", "http://sgkodi.de/KidsTube/Daten/Grisu.png"),
	 ("[COLORorange]Alfred J Kwak[/COLOR] 1. Klassik Serie", "playlist/PL58016D15BD79A97F", "http://sgkodi.de/KidsTube/Daten/Alfred.png"),
	 ("[COLORorange]Scooby Doo[/COLOR] 1. Klassik Serie", "playlist/PLJYf0JdTApCqEYfW77tMTtqN-gA65_LPW", "http://sgkodi.de/KidsTube/Daten/Scooby.png"),
	 ("[COLORorange]FLIPPER[/COLOR] Staffel 1", "playlist/PLHEDxAYF32QJmHISru7c-MZn_sYt9MpCL", "http://sgkodi.de/KidsTube/Daten/Flipper.png"),
	 ("[COLORorange]FLIPPER[/COLOR] Staffel 2", "playlist/PLHEDxAYF32QIXWcvfBkxxzmfW6xI-i4Gl", "http://sgkodi.de/KidsTube/Daten/Flipper.png"),
	 ("[COLORorange]FLIPPER[/COLOR] Staffel 3", "playlist/PLHEDxAYF32QJPtxGimOndyo8VunXLk62Q", "http://sgkodi.de/KidsTube/Daten/Flipper.png"),
	 ],

'Filme':[
     ("[COLORyellow]Kinderfilme[/COLOR] von Netzkino", "playlist/PLfEblejE-l3k5xxDsBiKVhdNqWAuCIYRr", "http://sgkodi.de/KidsTube/Daten/Netzkino.png"),
     ("[COLORyellow]Zeichentrickfilme[/COLOR] von Netzkino", "playlist/PLfEblejE-l3l8AwrdcuMp-p31uwBaJJXl", "http://sgkodi.de/KidsTube/Daten/Netzkino.png"),
     ("[COLORyellow]Pferdefilme[/COLOR] von Netzkino", "playlist/PLfEblejE-l3k3qM4Q1GlnGdGeRjzlZvRn", "http://sgkodi.de/KidsTube/Daten/Netzkino.png"),
	 ("[COLORyellow]Hundefilme[/COLOR] von Netzkino", "playlist/PLfEblejE-l3nIBgJeAv7KO1DPvC2yN8-5", "http://sgkodi.de/KidsTube/Daten/Netzkino.png"),
	 ("[COLORyellow]Tennie Komödien[/COLOR] von Netzkino", "playlist/PLfEblejE-l3kyX48AXCaOnKFLxxkasxOM", "http://sgkodi.de/KidsTube/Daten/Netzkino.png"),
	 ("[COLORyellow]Familienkino[/COLOR] von Netzkino", "playlist/PLfEblejE-l3nta_dpVmIwGomgE_a3sm6g", "http://sgkodi.de/KidsTube/Daten/Netzkino.png"),
	 ("[COLORyellow]Weihnachtskino[/COLOR] von Netzkino", "playlist/PLfEblejE-l3n9NKla09pwoYVLtnrL2kv3", "http://sgkodi.de/KidsTube/Daten/Netzkino.png"),
	 ("[COLORyellow]Kinderkino[/COLOR] von Netzkino", "channel/UCmZUsl5MLqXIhuSTVP6x-EA", "http://sgkodi.de/KidsTube/Daten/Kinderkino.png"),
	 ("[COLORorange]Kinderfilme[/COLOR] von Kixi", "playlist/PLAroxwS0jZuS521YByzaxA6ZO5VO-ppXJ", "http://sgkodi.de/KidsTube/Daten/Kixi.png"),
	 ("[COLORorange]Zeichentrickfilme[/COLOR] von Kixi", "playlist/PLAroxwS0jZuQSy2pjwruhzz44-kQ0YHEh", "http://sgkodi.de/KidsTube/Daten/Kixi.png"),
	 ("[COLORorange]Tierfilme[/COLOR] von Kixi", "playlist/PLAroxwS0jZuQQlgJJ3_-imn1abL4A4Zlc", "http://sgkodi.de/KidsTube/Daten/Kixi.png"),
	 ("[COLORorange]Hundefilme[/COLOR] von Kixi", "playlist/PLAroxwS0jZuQC6yoU8LJF3USzgQBlrzx5", "http://sgkodi.de/KidsTube/Daten/Kixi.png"),
	 ("[COLORorange]Familienfilme[/COLOR] von Kixi", "playlist/PLAroxwS0jZuQUBhbxcAUlfh9qeJGV_tom", "http://sgkodi.de/KidsTube/Daten/Kixi.png"),
	 ("[COLORorange]Weihnachtsfilmefilme[/COLOR] von Kixi", "playlist/PLAroxwS0jZuTLDgN-YeW2Yy0trylROSs4", "http://sgkodi.de/KidsTube/Daten/Kixi.png"),
	 ],	 
	 
'Geschichten':[
     ("[COLORyellow]Unser Sandmännchen[/COLOR] von RBB", "user/sandmannshop", "http://sgkodi.de/KidsTube/Daten/Sand.png"),
	 ("[COLORyellow]German Fairy Tales[/COLOR]", "playlist/PLYJXC9hVK9ZdUXMrhOTC-kpfIEwJQ2c0u", "http://sgkodi.de/KidsTube/Daten/Fairy.png"),
	 ("[COLORyellow]Märchen für Kinder[/COLOR] Gutenachtgeschichten", "playlist/PLRSUQa10y6VFV1kYPPc1hH0kSksmCvGU1", "http://sgkodi.de/KidsTube/Daten/Maerchen.png"),
	 ("[COLORyellow]Gute Nacht Geschichten[/COLOR] DE.BedtimeStory.TV", "playlist/PLSeYZc0WTfTc-eqLP1bZLj0fJ13ZVfzBv", "http://sgkodi.de/KidsTube/Daten/Bed.png"),
	 ("[COLORyellow]Deine Märchenwelt[/COLOR] Märchen, Geschichten, Sagen", "playlist/PLvsVeezf83quto2DL-5J4ZPmm2cYgwaFU", "http://sgkodi.de/KidsTube/Daten/Maerchen.png"),
	 ("[COLORyellow]Geschichten für Kinder[/COLOR]", "playlist/PLT8zuqWPJkYAJI2jiNa67Q3YaRMOVR-uL", "http://sgkodi.de/KidsTube/Daten/Kids.png"),
	 ("[COLORyellow]SimsalaGrimm[/COLOR]", "playlist/PLN5h7nQDQsiNAygibR61TxqtquFrvydt6", "http://sgkodi.de/KidsTube/Daten/Grimm.png"),
	 ("[COLORyellow]Grimms Märchen[/COLOR] Filme", "playlist/PL9A89EE24241DACF2", "http://sgkodi.de/KidsTube/Daten/Grimm2.png"),
	 ],

'Buch':[
	 ("[COLORyellow]Kinder- & Jugend Hörspiele[/COLOR] HoerTalk", "playlist/PL6IcxBEYItDV7PWjFYdnHF9IsvAAGPaRx", "http://sgkodi.de/KidsTube/Daten/Talk.png"),
	 ("[COLORyellow]Jugend Hörspiele[/COLOR] Spooks", "playlist/PLBCqvaIr4yUkjmEq5okDt5UAcNhqPgbq6", "http://sgkodi.de/KidsTube/Daten/Spooks.png"),
	 ("[COLORyellow]PUMUCKL Hörspiele 1960-1975[/COLOR] Hörspiel Fabrik", "playlist/PLv_ENFPXiu3hRZIrlhauZbojCmT_N6mJf", "http://sgkodi.de/KidsTube/Daten/Pumuckl.png"),
	 ("[COLORyellow]TIM & STRUPPI Hörspiele[/COLOR] Hörspiel Fabrik", "playlist/PLv_ENFPXiu3h0BNMfk7NvPyEkZVpZgE6P", "http://sgkodi.de/KidsTube/Daten/Tim.png"),
	 ("[COLORyellow]BENJAMIN BLÜMCHEN Hörspiele[/COLOR] BenjaminBlümchen.tv", "playlist/PL1SAyTUFBb762GpJFH19_NvETovF_-NXu", "http://sgkodi.de/KidsTube/Daten/Ben.png"),
	 ("[COLORyellow]BIBI BLOCKSBERG[/COLOR] BibiBlocksberg.tv", "playlist/PLOZg6nrLYB79IpjmXsBPoq2tuW1DjEb1J", "http://sgkodi.de/KidsTube/Daten/Bibi.png"),
	 ("[COLORyellow]BARBIE Hörspiele[/COLOR] ", "playlist/PLTIFt51Pse_rIf7mf0uLdqXzgdbkwJ2kf", "http://sgkodi.de/KidsTube/Daten/Barbie.png"),
	 ("[COLORyellow]KASPERLE Hörspiele[/COLOR] Eulenspiegel", "playlist/PLWf5n0LLW8SH2w3gSefz2uQyEQiWWMues", "http://sgkodi.de/KidsTube/Daten/Kasper.png"),
	 ("[COLORyellow]GRIMMS Märchen Hörspiele[/COLOR] Märchenwelt", "playlist/PL_7pajp36h-R_VBtOQMaFg7SAmlT02fX8", "http://sgkodi.de/KidsTube/Daten/Grimm2.png"),
	 ("[COLORyellow]Märchen Hörspiele[/COLOR] Hörspiel Fuchs", "playlist/PL49N08rhGF4dp7S5egoLmLT50_MqtTtVD", "http://sgkodi.de/KidsTube/Daten/Maerchen.png"),
	 ("[COLORyellow]Märchen Hörspiele[/COLOR] Hörspiel Cafe", "playlist/PLSw94V8UrQVpzaPo-ajaueBLKUM2QxdnH", "http://sgkodi.de/KidsTube/Daten/Maerchen.png"),
	 ("[COLORyellow]Klassische Hörspiele[/COLOR] Märchenwelt", "playlist/PL_7pajp36h-QXzz1ncxNJFtg2GZzHV1dL", "http://sgkodi.de/KidsTube/Daten/Klassik.png"),
	 ("[COLORyellow]Christliche Hörspiele[/COLOR] die Bibel", "channel/UCJSF-0y7Pz7VUNH3cCdqwLw", "http://sgkodi.de/KidsTube/Daten/Bibel.png"),
     ],
 
'Wissen':[
     ("[COLORyellow]PIXI[/COLOR] Wissen TV", "playlist/PLHKaBnKI1TKo__fOVrZIDHibsTqsuKjDL", "http://sgkodi.de/KidsTube/Daten/Pixi.png"),
	 ("[COLORyellow]KiWi[/COLOR] Schlaue Fragen, schlaue Antworten!", "playlist/PLVWZ8fAnW6IbmOFpTtp6ImFFW-K4T83YN", "http://sgkodi.de/KidsTube/Daten/Schlau.png"),
	 ("[COLORyellow]KiWi[/COLOR] Professor Schlaufuchs", "playlist/PLVWZ8fAnW6IbqKL4j7uaR4RtPsqB6rKc0", "http://sgkodi.de/KidsTube/Daten/Fuchs.png"),
	 ("[COLORyellow]Planet Schule[/COLOR] von ARD", "playlist/PLQrsocOZ_VCkUNiNOi7peXmZDK5wVzRsT", "http://sgkodi.de/KidsTube/Daten/Schule.png"),
	 ("[COLORyellow]Checker Welt[/COLOR] Experimente", "playlist/PLXHkZNhCrU2ZGzKXPeq_8NY8ZF3coQyR9", "http://sgkodi.de/KidsTube/Daten/Checker.png"),
	 ("[COLORyellow]DIY Inspiration Kids Club[/COLOR] Experimente", "playlist/PLjXEwjXTkbzqewdd_3DTgb0GZ_0LhECPJ", "http://sgkodi.de/KidsTube/Daten/DIY.png"),
	 ("[COLORyellow]PAXI[/COLOR] European Space Agency", "playlist/PLbyvawxScNbvwcIVrGQV4p6g6cp9pH0To", "http://sgkodi.de/KidsTube/Daten/Paxi.png"),
     ],

'Musik':[
     ("[COLORyellow]Sing mit Mir[/COLOR] Kinderlieder", "playlist/PLu791Jb5lWoCOzceiS6SDeGW_u1s7x-0h", "http://sgkodi.de/KidsTube/Daten/Sing.png"),
	 ("[COLORyellow]Hurra[/COLOR] Kinderlieder", "playlist/PLz8hTTrU37YTw06tseX2sHpXMbDK9x_Ds", "http://sgkodi.de/KidsTube/Daten/Hurra.png"),
	 ("[COLORyellow]Kinderlieder[/COLOR] zum Mitsingen und Tanzen", "playlist/PLM9BsUcYb5Mn8xN72IX5LUHj25_ssTN5_", "http://sgkodi.de/KidsTube/Daten/Beste.png"),
	 ("[COLORyellow]Karaoke[/COLOR] Kinderlieder mit Bien Maja, Wickie und Co.", "playlist/PLCywMP0BLGOk_cTbmLNENN711N3Yw0hRF", "http://sgkodi.de/KidsTube/Daten/Karaoke.png"),
	 ("[COLORyellow]Disney[/COLOR] Titelmusik", "playlist/PL4BrNFx1j7E6a6IKg8N0IgnkoamHlCHWa", "http://sgkodi.de/KidsTube/Daten/DisneyM.png"),
	 ("[COLORyellow]KinderliederTV.de[/COLOR]", "playlist/PLmMaywx47bx5w5YJ3uLJz73X81srE4wlQ", "http://sgkodi.de/KidsTube/Daten/KTV.png"),
	 
	 ],
	 
    }


# Entry point
def run():
    plugintools.log("KidsTube.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        sub_list(action)
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("KidsTube.main_list "+repr(params))

    for name, id, icon in channellist:
        url = sys.argv[0] + "?action=" + id
        plugintools.add_item(title=name,url=url,thumbnail=icon,folder=True )

def sub_list(action):
    plugintools.log("KidsTube.sub_list "+repr(action))
    for List in sublists[str(action)]:
        name = List[0]
        id = List[1]
        icon = List[2]
        plugintools.add_item(title=name,url="plugin://plugin.video.youtube/"+id+"/",thumbnail=icon,folder=True )        

run()