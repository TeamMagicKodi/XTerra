# -*- coding: utf-8 -*-

from resources.lib import kodiutils
from resources.lib import kodilogging
import io
import os
import sys
import time
import zipfile
import urllib
import logging
import xbmcaddon
import xbmcgui
import xbmc
import shutil
import zfile as zipfile


ADDON = xbmcaddon.Addon()
logger = logging.getLogger(ADDON.getAddonInfo('id'))


class Canceled(Exception):
    pass


class MyProgressDialog():
    def __init__(self, process):
        self.dp = xbmcgui.DialogProgress()
        self.dp.create("PsycoTV", process, '', '')

    def __call__(self, block_num, block_size, total_size):
        if self.dp.iscanceled():
            self.dp.close()
            raise Canceled
        percent = (block_num * block_size * 100) / total_size
        if percent < total_size:
            self.dp.update(percent)
        else:
            self.dp.close()


def read(response, progress_dialog):
    data = b""
    total_size = response.info().getheader('Content-Length').strip()
    total_size = int(total_size)
    bytes_so_far = 0
    chunk_size = 1024 * 1024
    reader = lambda: response.read(chunk_size)
    for index, chunk in enumerate(iter(reader, b"")):
        data += chunk
        progress_dialog(index, chunk_size, total_size)
    return data


def extract(zip_file, output_directory, progress_dialog):
    addonPath = xbmc.translatePath('special://home/addons').decode('utf-8')
    userPath = xbmc.translatePath('special://home/userdata').decode('utf-8')
    addonPathNew = xbmc.translatePath('special://home/addonsAlt').decode('utf-8')
    userPathNew = xbmc.translatePath('special://home/userdataAlt').decode('utf-8')
    shutil.move(addonPath,addonPathNew)
    shutil.move(userPath,userPathNew)
    shutil.rmtree(addonPathNew, ignore_errors=True)
    shutil.rmtree(userPathNew, ignore_errors=True)
    zin = zipfile.ZipFile(zip_file)
    files_number = len(zin.infolist())
    for index, item in enumerate(zin.infolist()):
        try:
            progress_dialog(index, 1, files_number)
        except Canceled:
            return False
        else:
            zin.extract(item, output_directory)
    return True


def get_packages():
    yesnowindow = xbmcgui.Dialog().yesno('PsycoTV', 'PsycoTV Auto-Update: ','Update verfügbar!','Willst du das Update installieren?', yeslabel='Ja',nolabel='Später')
    dialog = xbmcgui.Dialog()
    if yesnowindow == 1:
        addon_name = ADDON.getAddonInfo('name')
        url = 'http://psyco.tv/user/psyco/data.zip'
        response = urllib.urlopen(url)
        try:
            data = read(response, MyProgressDialog("PsycoTV wird aktualisiert. Daten werden heruntergeladen..."))
        except Canceled:
            message = "Download abgebrochen"
        else:
            addon_folder = xbmc.translatePath(os.path.join('special://', 'home'))
            if extract(io.BytesIO(data), addon_folder, MyProgressDialog("PsycoTV wird aktualisiert. Daten werden entpackt...")):
                message = "PsycoTV wurde erfolgreich aktualisiert"
            else:
                message = "Die Aktualisierung wurde abgebrochen"
        dialog = xbmcgui.Dialog()
        dialog.ok(addon_name, "%s. Die App wird nun geschlossen. Bitte die App erneut öffnen." % message)
        os._exit(0)
    else:
        dialog.ok('PsycoTV','Ok, beim nächsten Start wird erneut gefragt.','')
