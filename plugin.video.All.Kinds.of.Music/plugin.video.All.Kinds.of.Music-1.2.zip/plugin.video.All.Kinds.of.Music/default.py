#!/usr/bin/python
# -*- coding: utf-8 -*-
import os
import sys
import plugintools
import xbmc,xbmcaddon
import base64
import hashlib
from addon.common.addon import Addon

addonID = xbmcaddon.Addon().getAddonInfo('id')
addon = xbmcaddon.Addon()
addon_path = addon.getAddonInfo('path').decode('utf-8')
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')
fanart = local.getAddonInfo('fanart')

YOUTUBE_CHANNEL_ID1 = "PL6D4C31FFA7EBABB5"
YOUTUBE_CHANNEL_ID2 = "PLB5axqo_BYe1JqK7mXkjhx-4p_qiAw-5I"
YOUTUBE_CHANNEL_ID3 = "PLJhKEt4Hct7X5ox53HIqxCHRdhghj581o"
YOUTUBE_CHANNEL_ID4 = "PLsGK3aH9-P9nqEH-M-TKEnAcBNxhq1ljq"
YOUTUBE_CHANNEL_ID5 = "PLGXbBW1RbSb4UPshkqvYOO43L5_p5A5j4"
YOUTUBE_CHANNEL_ID6 = "PLSJkIg_k31H_oFwE8vqFiVC3i5a-q8a-C"
YOUTUBE_CHANNEL_ID7 = "PLMC9KNkIncKtsacKpgMb0CVq43W80FKvo"
YOUTUBE_CHANNEL_ID8 = "PLI_7Mg2Z_-4KU0S6_qMAojurEZ2C__j8w"
YOUTUBE_CHANNEL_ID9 = "PLgwLwE95SwXPiOEPk8HXTrYy95yDKsUNV"
YOUTUBE_CHANNEL_ID10 = "PLpuDUpB0osJmZQ0a3n6imXirSu0QAZIqF"
YOUTUBE_CHANNEL_ID11 = "PL05E1623111A9A860"
YOUTUBE_CHANNEL_ID12 = "PLE19ADDE73A2A9499"
YOUTUBE_CHANNEL_ID13 = "PL09eGQfW13QjtcB0nITNYP56g8OMKe0uc"
YOUTUBE_CHANNEL_ID14 = "PLCD0445C57F2B7F41"
YOUTUBE_CHANNEL_ID15 = "PL7DA3D097D6FDBC02"
YOUTUBE_CHANNEL_ID16 = "PLK9Sc5q_4K6aNajVLKtkaAB1JGmKyccf2"
YOUTUBE_CHANNEL_ID17 = "PLMOnUdcodDmS7Ji3CWZReR6mFWtNBkO8l"
YOUTUBE_CHANNEL_ID18 = "PLs-kfwmk-th7qSMbgpg3Fq6XQQsgFA02b"
YOUTUBE_CHANNEL_ID19 = "PL09eGQfW13QgGH50QDnsE01bf9n3eJJz0"
YOUTUBE_CHANNEL_ID20 = "PL5219C5FC3806FEA9"
YOUTUBE_CHANNEL_ID21 = "PLd5xnond3B5Q8RQpGlrlvZv0n4_hpvxNv"
YOUTUBE_CHANNEL_ID22 = "PL61EE4ED086789D1C"
YOUTUBE_CHANNEL_ID23 = "PL09eGQfW13QhaQTz8guvp0x03_3OoOCdP"
YOUTUBE_CHANNEL_ID24 = "PLw-VjHDlEOgtwFlySm1JHphU3j8wUtSlu"
YOUTUBE_CHANNEL_ID25 = "PLxvodScTx2RsV2VIDIBksBmuLFngu3mgU"
YOUTUBE_CHANNEL_ID26 = "PLhYloEd6Z5nWzry65UghGYAnXH-j5NOGy"
YOUTUBE_CHANNEL_ID27 = ""
YOUTUBE_CHANNEL_ID28 = ""
YOUTUBE_CHANNEL_ID29 = ""
YOUTUBE_CHANNEL_ID30 = ""
YOUTUBE_CHANNEL_ID31 = ""
YOUTUBE_CHANNEL_ID32 = ""
YOUTUBE_CHANNEL_ID33 = ""
YOUTUBE_CHANNEL_ID34 = ""
YOUTUBE_CHANNEL_ID35 = ""

def run():
    plugintools.log("VORLAGE.run")
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        pass
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("All Kinds of Musik-Videos.main_list"+repr(params))  


    plugintools.add_item( 
        #action="", 
        title=" [B][COLOR lightskyblue]German TOP 100 Single Charts [/COLOR][/B]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID1+"/",
		thumbnail="https://i.ytimg.com/vi/8HSvsModtVg/maxresdefault.jpg",
        fanart="",
        folder=True )

    plugintools.add_item(
        #action="",
        title=" [B][COLOR lightskyblue]Top 100 Schlager Charts[/COLOR][/B]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID2+"/",
        thumbnail="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS4WfpttBJIgdpdtGCBOgETWez_7Ydh7Ekm5phS75SZIgzRJmcN",
        fanart="",
        folder=True )

    plugintools.add_item(
        #action="",
        title=" [B][COLOR lightskyblue]iTunes Top 100 US (2019)[/COLOR][/B]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID3+"/",
        thumbnail="https://img.freepik.com/freie-ikonen/itunes_318-133846.jpg?size=338&ext=jpg",
        fanart="",
        folder=True )

    plugintools.add_item(
        #action="",
        title=" [B][COLOR lightskyblue]Musik Mix HD [/COLOR][/B]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID4+"/",
        thumbnail="https://cdn3.iconfinder.com/data/icons/multimedia-13/63/high-def-512.png",
        fanart="",
        folder=True )
		
    plugintools.add_item(
        #action="",
        title=" [B][COLOR lightskyblue]Sounds of Summer 2019[/COLOR][/B]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID5+"/",
        thumbnail="https://www.dropbox.com/s/d8lu4hp5ls039kv/Dance2.jpg?dl=1",
        fanart="",
        folder=True )
		
    plugintools.add_item(
        #action="",
        title=" [B][COLOR lightskyblue]Die besten Sommerhits 2019 - Coole Songs für Heiße Tage 2019[/COLOR][/B]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID6+"/",
        thumbnail="https://www.dropbox.com/s/pjqqrnssta5yroa/Dance5.jpg?dl=1",
        fanart="",
        folder=True )
		
    plugintools.add_item(
        #action="",
        title=" [B][COLOR lightskyblue]Summer Hits 2019 (Best Summer Songs)[/COLOR][/B]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID7+"/",
        thumbnail="https://www.dropbox.com/s/0cvwe88wnqeer7c/Dance1.jpg?dl=1",
        fanart="",
        folder=True )   
		
    plugintools.add_item(
        #action="",
        title=" [B][COLOR lightskyblue]Best Old Summer Music (Updated 2019)[/COLOR][/B]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID8+"/",
        thumbnail="https://www.dropbox.com/s/wo0vkhrcskixm2w/Dance4.jpg?dl=1",
        fanart="",
        folder=True )		
		
    plugintools.add_item(
        #action="",
        title=" [B][COLOR lightskyblue]Best songs of Hiphop from 2000-2019[/COLOR][/B]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID9+"/",
        thumbnail="https://www.dropbox.com/s/l3ca0en2tq9vp6i/1A%202000er%20Hits.jpg?dl=1",
        fanart="",
        folder=True )		
    
    plugintools.add_item(
        #action="",
        title=" [B][COLOR lightskyblue]2000's Hits[/COLOR][/B]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID10+"/",
        thumbnail="https://www.dropbox.com/s/l3ca0en2tq9vp6i/1A%202000er%20Hits.jpg?dl=1",
        fanart="",
        folder=True )	
		
    plugintools.add_item(
        #action="",
        title=" [B][COLOR lightskyblue]Top Hits of the 2000's[/COLOR][/B]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID11+"/",
        thumbnail="https://www.dropbox.com/s/5mwdv1er81bgjr0/i%20love.png?dl=1",
        fanart="",
        folder=True )
		
    plugintools.add_item(
        #action="",
        title=" [B][COLOR lightskyblue]100 Best Rock Songs of 2000's[/COLOR][/B]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID12+"/",
        thumbnail="https://www.dropbox.com/s/kns3fss5krbbtsf/1A%20Rock%20Songs.jpg?dl=1",
        fanart="",
        folder=True )		

    plugintools.add_item(
        #action="",
        title=" [B][COLOR lightskyblue] Best of 70s Music[/COLOR][/B]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID13+"/",
        thumbnail="https://www.dropbox.com/s/bt90uj33mp6vtnp/images.jpg?dl=1",
        fanart="",
        folder=True )	

    plugintools.add_item(
        #action="",
        title=" [B][COLOR lightskyblue] Greatest Hits (Best 80s Songs)[/COLOR][/B]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID14+"/",
        thumbnail="https://www.dropbox.com/s/nej18b4fhdtm0ex/80er.jpg?dl=1",
        fanart="",
        folder=True )	

    plugintools.add_item(
        #action="",
        title=" [B][COLOR lightskyblue] Greatest 90's Music Hits [/COLOR][/B]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID15+"/",
        thumbnail="https://www.dropbox.com/s/vipki2z661lgdd9/90s.jpg?dl=1",
        fanart="",
        folder=True )	
		
    plugintools.add_item(
        #action="",
        title=" [B][COLOR lightskyblue]ROCK / Pop HITS 70's/80's/90's/00's [/COLOR][/B]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID16+"/",
        thumbnail="https://www.dropbox.com/s/td2qklwc3vmixle/Rock%20Musik.jpg?dl=1",
        fanart="",
        folder=True )				

    plugintools.add_item(
        #action="",
        title=" [B][COLOR lightskyblue]Deutschrock - Bester Rock für Dich Volume1[/COLOR][/B]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID17+"/",
        thumbnail="https://www.dropbox.com/s/tlsa1ux87rxkr0b/Deutschrock.png?dl=1",
        fanart="",
        folder=True )		

    plugintools.add_item(
        #action="",
        title=" [B][COLOR lightskyblue]Deutschrock - Bester Rock für Dich Volume2[/COLOR][/B]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID18+"/",
        thumbnail="https://www.dropbox.com/s/tlsa1ux87rxkr0b/Deutschrock.png?dl=1",
        fanart="",
        folder=True )		

    plugintools.add_item(
        #action="",
        title=" [B][COLOR lightskyblue]Deutsch - Pop / Rock [/COLOR][/B]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID19+"/",
        thumbnail="https://www.dropbox.com/s/5tc9acfj1p5rtba/Rock%20Pop%202.jpg?dl=1",
        fanart="",
        folder=True )		

    plugintools.add_item(
        #action="",
        title=" [B][COLOR lightskyblue]Deutsche Lieder - Gemischt[/COLOR][/B]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID20+"/",
        thumbnail="https://www.dropbox.com/s/23f3mm5tsribn8j/German-wallpaper74.jpg?dl=1",
        fanart="",
        folder=True )		

    plugintools.add_item(
        #action="",
        title=" [B][COLOR lightskyblue]Neue Deutsche Welle 80s[/COLOR][/B]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID21+"/",
        thumbnail="https://www.dropbox.com/s/sbvo422jwyqyqq6/Neue%20deutsche%20Welle.jpg?dl=1",
        fanart="",
        folder=True )		

    plugintools.add_item(
        #action="",
        title=" [B][COLOR lightskyblue]Schlager Marathon[/COLOR][/B]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID22+"/",
        thumbnail="https://www.dropbox.com/s/0klb6c3s4vzpgic/1A%20Party%20Schlager.jpg?dl=1",
        fanart="",
        folder=True )

    plugintools.add_item(
        #action="",
        title=" [B][COLOR lightskyblue]Party & Schlager - Hits[/COLOR][/B]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID23+"/",
        thumbnail="https://www.dropbox.com/s/h8lkbsnhy1m7kjr/1A%20Party%20Hits.jpg?dl=1",
        fanart="",
        folder=True )	

    plugintools.add_item(
        #action="",
        title=" [B][COLOR lightskyblue]Die besten Deutsche Lieder aller Zeiten[/COLOR][/B]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID24+"/",
        thumbnail="https://www.dropbox.com/s/dh0uf6b24d8ehrx/1A%20Deutsche%20Hits.jpg?dl=1",
        fanart="",
        folder=True )						
		
    plugintools.add_item( 
        title="[B][COLOR lightskyblue] Best New Reggae 2019  [/COLOR][/B]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID25+"/",
        thumbnail="https://www.dropbox.com/s/0uqicooja8id4oi/This%20is%20reggea%20musik.png?dl=1",
        fanart="",
        folder=True )						
		
    plugintools.add_item( 
        title="[B][COLOR lightskyblue]Kuschelrock [/COLOR][/B]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID26+"/",
        thumbnail="https://www.dropbox.com/s/5ihu4acewhfro52/Kuschelrock.jpg?dl=1",
        fanart="",
        folder=True )					
			
run()
