4TH Oct 216

Added Profile fix for people that use multiple profiles

Default takes the creator settings back to master profile

Looking to add better filtering  on ini creation (work in progress)
With the removal of special charecters.