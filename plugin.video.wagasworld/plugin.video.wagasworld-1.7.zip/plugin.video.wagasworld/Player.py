import xbmcaddon

MainBase = 'https://bit.ly/30Moz71'
addon = xbmcaddon.Addon('plugin.video.wagasworld')