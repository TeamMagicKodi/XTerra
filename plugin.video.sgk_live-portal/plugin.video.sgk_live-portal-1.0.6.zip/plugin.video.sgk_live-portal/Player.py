 # -*- coding: utf-8 -*- 

import base64, codecs
import xbmcaddon

MainBase = base64.b64decode('aHR0cDovL3Nna29kaS5kZS9TR0stUG9ydGFsL3BvcnRhbC54bWw=')
addon = xbmcaddon.Addon('plugin.video.sgk_live-portal')