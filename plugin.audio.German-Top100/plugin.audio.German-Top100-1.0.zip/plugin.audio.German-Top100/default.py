#!/usr/bin/python
# -*- coding: utf-8 -*-
import os
import sys
import plugintools
import xbmc,xbmcaddon
import base64
import hashlib
from addon.common.addon import Addon

addonID = xbmcaddon.Addon().getAddonInfo('id')
addon = xbmcaddon.Addon()
addon_path = addon.getAddonInfo('path').decode('utf-8')
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')
fanart = local.getAddonInfo('fanart')

YOUTUBE_CHANNEL_ID1 = "PLD7SPvDoEddZ4awWJjYEQdI10UP-9sGkO"
YOUTUBE_CHANNEL_ID2 = "PLB5axqo_BYe1JqK7mXkjhx-4p_qiAw-5I"
YOUTUBE_CHANNEL_ID3 = "PLJhKEt4Hct7Uwl8eNXnmBoBHj0HPeRJi-"
YOUTUBE_CHANNEL_ID4 = "PLMJy5xZa41s7YSGS9S6FbKZEilLnlW_7o"
YOUTUBE_CHANNEL_ID5 = "PLRbAgAjyBgD_g1-IIlaXUcjtdj11CIizl"
YOUTUBE_CHANNEL_ID6 = ""
YOUTUBE_CHANNEL_ID7 = ""
YOUTUBE_CHANNEL_ID8 = ""
YOUTUBE_CHANNEL_ID9 = ""
YOUTUBE_CHANNEL_ID10 = ""
YOUTUBE_CHANNEL_ID11 = ""
YOUTUBE_CHANNEL_ID12 = ""
YOUTUBE_CHANNEL_ID13 = ""

def run():
    plugintools.log("VORLAGE.run")
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        pass
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("German Top100-Videos.main_list"+repr(params))
   


    plugintools.add_item( 
        #action="", 
        title="- [B][COLOR lightskyblue]German TOP 100 Single Charts [/COLOR][/B]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID1+"/",
		thumbnail="https://i.ytimg.com/vi/8HSvsModtVg/maxresdefault.jpg",
        fanart="http://i056.radikal.ru/1711/f5/8edb010a9953.jpg",
        folder=True )

    plugintools.add_item(
        #action="",
        title="- [B][COLOR lightskyblue]Top 100 Schlager Charts[/COLOR][/B]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID2+"/",
        thumbnail="https://www.vn.at/2018/03/vn-abonnenten-besuchen-die-schlagernacht-500x293.jpg",
        fanart="https://img6.androidappsapk.co/300/3/4/f/at.ncn.schlagercharts.png",
        folder=True )

    plugintools.add_item(
        #action="",
        title="- [B][COLOR lightskyblue]iTunes Top 100 DANCE (2018)[/COLOR][/B]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID3+"/",
        thumbnail="http://ordinarymedic.com/imag/Dance-Hits-2018.jpg",
        fanart="https://imagescdn.junodownload.com/full/CS2138573-02A-BIG.jpg",
        folder=True )

    plugintools.add_item(
        #action="",
        title="- [B][COLOR lightskyblue]VIVA Top 100 2018.[/COLOR][/B]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID4+"/",
        thumbnail="http://www.revolverpromotion.com/wp-content/uploads/2017/12/fullsizeoutput_6dbb-800x600.jpeg",
        fanart="http://www.adamnews.de/wp-content/uploads/2015/12/Watch-VIVA-TV-Live-TV-from-Germany.jpg",
        folder=True )

    plugintools.add_item(
        #action="",
        title="- [B][COLOR lightskyblue]Sommerhits[/COLOR][/B]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID5+"/",
        thumbnail="https://d1mpwj8ap32onb.cloudfront.net/static/playlist/4867701/b577f89618e32dc.jpg",
        fanart="https://d1mpwj8ap32onb.cloudfront.net/static/playlist/4867701/b577f89618e32dc.jpg",
        folder=True )

    

run()
