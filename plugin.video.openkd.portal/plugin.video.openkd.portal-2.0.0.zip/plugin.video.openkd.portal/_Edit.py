import xbmcaddon

MainBase = 'http://openkd.tv/homepage/files/OpenKD_Portal/portal.txt'
addon = xbmcaddon.Addon('plugin.video.openkd.portal')